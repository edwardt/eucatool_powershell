.. ref-mapreduce

=========
mapreduce
=========

.. note::

   I am not sure why pdb_delete, pdb_revert, pdb_describe, and pdb_upload are not available for import.


boto.mapreduce
--------------

.. automodule:: boto.mapreduce
   :members:   
   :undoc-members:

boto.mapreduce.lqs
------------------

.. automodule:: boto.mapreduce.lqs
   :members:   
   :undoc-members:

boto.mapreduce.partitiondb
--------------------------

.. automodule:: boto.mapreduce.partitiondb
   :members:   
   :undoc-members:

boto.mapreduce.queuetools
-------------------------

.. automodule:: boto.mapreduce.queuetools
   :members:   
   :undoc-members:
