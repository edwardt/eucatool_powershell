.. _ref-index:

=============
API Reference
=============

.. toctree::
   :maxdepth: 4

   boto
   cloudfront
   contrib
   ec2
   fps
   manage
   mapreduce
   mashups
   mturk
   pyami
   s3
   sdb
   services
   sqs
   vpc